const momenttz = require('moment-timezone');
const moment = require('moment');
const APP_NAME = "Template Eleven"
///
const Alexa = require('ask-sdk-core');
//url Api
// Londre = https://dxm94wb2ub.execute-api.eu-west-2.amazonaws.com/pre-prod/live/current-or-next
//paris =https://5i0r9p1nwh.execute-api.eu-west-3.amazonaws.com/dev/live/current-or-next
const ApiUrl="https://5i0r9p1nwh.execute-api.eu-west-3.amazonaws.com/dev/live/current-or-next"

const headers = {headers: {"x-api-key": "L7QF50ujQm57MqDJxBB789rUGhkJ0FvB3fYOqYrl", 'Content-Type': 'application/ld+json',}}

var broadcasterEngineStatus ='stopped' // Etat de la diffusion
var StreamUrl=' https://blablafoot.com/replay/2020_05_21_1_F4.mp3' //url deflux
var LiveName ='Le foot français à lheure du rachat ' // nom de live
var LiveDate =1591736400 // date de début
//lien du flux
//url test hls= https://cpdc101-lh.akamaihd.net/i/ISNCPDCMB1_1@314337/master.m3u8
// url test mp3 = https://blablafoot.com/replay/2020_05_21_1_F4.mp3
//url test flux continu= https://audio1.maxi80.com
const StartDiffusionMessage= "Début de la diffusion!"
const NoDiffusionAvailable ="Aucune émission en cours actuellement, "
const ErrorMessage="De nouvelles émissions arrivent, revenez plus tard pour plus d'information"
//pause dans la voix
const SpeakBreak= '                                         ,'
//conversion de la date en timeStamp en format usuelle
const OneDayTimeStampDuration=86400

function timeConverter(t) {     
    var a = new Date(t *1000);
    var today = new Date();
    var tomorrow = new Date(Date.now() + OneDayTimeStampDuration*1000)
    var months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    //gestion des cas de midi, minuit et des heures piles , min=0
    var Sayhour=hour
    var Wordheure= 'heure '
    if(min===0){
        min=''
    }
    
  if(hour===12){
      Sayhour='midi';
      Wordheure=''
  }else if (hour===0){
      Sayhour=  'minuit';
      Wordheure=''
  }
    
    //le même jour, le soir
    if ((a.setHours(0,0,0,0) === today.setHours(0,0,0,0))&& hour> 17)
        return 'ce soir  ' +' à partir de  ' + Sayhour+' '+  Wordheure + min;
    //le même jour l'après midi
    if ((a.setHours(0,0,0,0) === today.setHours(0,0,0,0))&& (13<hour) && (hour< 17))
        return 'cette après-midi  ' +' à partir de  ' + Sayhour+' '+  Wordheure + min;
    //le même jour le matin
    if ((a.setHours(0,0,0,0) === today.setHours(0,0,0,0)))
        return 'aujourd hui  ' +' à partir de  ' + Sayhour+' '+ Wordheure+ min;
    //le lendemain le soir
    else if (a.setHours(0,0,0,0) === tomorrow.setHours(0,0,0,0)&& hour> 17)
        return 'demain soir'+' à partir de ' + Sayhour+' '+  Wordheure+ min;
   //le lendemain après-midi
    else if (a.setHours(0,0,0,0) === tomorrow.setHours(0,0,0,0)&& (13<hour) && (hour< 17))
        return 'demain après-midi '+' à partir de ' + Sayhour+' '+  Wordheure + min;
    //le lendemain midi
    else if (a.setHours(0,0,0,0) === tomorrow.setHours(0,0,0,0)&& hour===12)
        return 'demain à ' + Sayhour+' '+ Wordheure + min;
   //le lendemain matin
    else if (a.setHours(0,0,0,0) === tomorrow.setHours(0,0,0,0))
        return 'demain matin '+' à partir de ' + Sayhour+' '+ Wordheure + min;
    // mois et/ou année différentes 
    else
        return 'le '+date + ' ' + month + ' à partir de   ' + Sayhour + Wordheure + min;
}

// supression des émoticones dans le titre
function removeEmojis (string) {
  var regex = /(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|\ud83c[\ude32-\ude3a]|\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff])/g;
  return string.replace(regex, ' ');
}

// lancer le stream 
const STREAMS = [
  {
    "token": "1",
    "url": StreamUrl,
    "metadata" : {
      "title": "Stream 2",
      "subtitle": "Live blabla foot",
      "art": {
        "sources": [
          {
            "contentDescription": "example image",
            "url": "https://s3.amazonaws.com/cdn.dabblelab.com/img/audiostream-starter-512x512.png",
            "widthPixels": 512,
            "heightPixels": 512
          }
        ]
      },
      "backgroundImage": {
        "sources": [
          {
            "contentDescription": "example image",
            "url": "https://s3.amazonaws.com/cdn.dabblelab.com/img/wayfarer-on-beach-1200x800.png",
            "widthPixels": 1200,
            "heightPixels": 800
          }
        ]
      }
    }
  }
];

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


const PlayStreamIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest' ||
      handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
        (
          handlerInput.requestEnvelope.request.intent.name === 'PlayStreamIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.ResumeIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.LoopOnIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NextIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.PreviousIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.RepeatIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.ShuffleOnIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StartOverIntent'
      );
  },

/////////////////////// APPELLE API
    async handle(handlerInput) {
    

    await getRemoteData(ApiUrl)
      .then((response) => {
        const data = JSON.parse(response);
            broadcasterEngineStatus= data.broadcasterEngineStatus //statut de diffusion
            LiveName= removeEmojis(data.mainSubject)      // Titre de l'émission, et supression des émoticones
            LiveDate= timeConverter(data.startDate) //date de début et conversion en language usuelle
            StreamUrl=data.broadcastWebURL // url de broadcast
            
      })
      .catch((err) => {
        //set an optiotnal error message here
        //outputSpeech = err.message;
      });
      
       const { requestEnvelope, serviceClientFactory, responseBuilder } = handlerInput;

    let {deviceId} = requestEnvelope.context.System.device;
    const upsServiceClient = serviceClientFactory.getUpsServiceClient();
   // const usertimeZone = await upsServiceClient.getSystemTimeZone(deviceId);
   // const now = momenttz.utc();
   // const localTime = now.tz(usertimeZone).format('h:mma');
   // let speechText2 = `Your timezone is ${usertimeZone}. Your local time is ${localTime}. `;


    var speechText =NoDiffusionAvailable +'néanmoins nous vous donnons rendez vous'+SpeakBreak+ LiveDate +',heure GMT,pour notre émission intitulée'+SpeakBreak+LiveName;
    if (broadcasterEngineStatus==='running') {
         let stream = STREAMS[0];
            stream.url= StreamUrl
             handlerInput.responseBuilder
      
            .addAudioPlayerPlayDirective('REPLACE_ALL', stream.url, stream.token, 0, null, stream.metadata);
           speechText = 'actuellement'+SpeakBreak+LiveName+SpeakBreak+StartDiffusionMessage+SpeakBreak;
          
         return handlerInput.responseBuilder
        .speak(speechText)
      .getResponse();
     } else if (broadcasterEngineStatus==='stopped'){
         
        return handlerInput.responseBuilder
      .speak(speechText)
      .getResponse();
  } else {
            speechText= ErrorMessage
          return handlerInput.responseBuilder
         .speak(speechText)
        .getResponse();
        
  }
    
  },
};


const HelpIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const speechText = 'Pour relancer la diffusion dite, reprendre, pour mettre en pause dite';

    return handlerInput.responseBuilder
      .speak(speechText)
      .getResponse();
  },
};




const CancelAndStopIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
        && (
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.PauseIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.LoopOffIntent' ||
          handlerInput.requestEnvelope.request.intent.name === 'AMAZON.ShuffleOffIntent'
        );
  },
  handle(handlerInput) {

    handlerInput.responseBuilder
      .addAudioPlayerClearQueueDirective('CLEAR_ALL')
      .addAudioPlayerStopDirective();

    return handlerInput.responseBuilder
      .getResponse();
  },
};

const PlaybackStoppedIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'PlaybackController.PauseCommandIssued' || 
            handlerInput.requestEnvelope.request.type === 'AudioPlayer.PlaybackStopped';
  },
  handle(handlerInput) {
    handlerInput.responseBuilder
      .addAudioPlayerClearQueueDirective('CLEAR_ALL')
      .addAudioPlayerStopDirective();

    return handlerInput.responseBuilder
      .getResponse();
  },
};

const PlaybackStartedIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'AudioPlayer.PlaybackStarted';
  },
  handle(handlerInput) {
    handlerInput.responseBuilder
      .addAudioPlayerClearQueueDirective('CLEAR_ENQUEUED');

    return handlerInput.responseBuilder
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder
      .getResponse();
  },
};

const ExceptionEncounteredRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'System.ExceptionEncountered';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return true;
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);
    console.log(handlerInput.requestEnvelope.request.type);
    return handlerInput.responseBuilder
      .getResponse();
  },
};

const getRemoteData = function (url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? require('https') : require('http');
    const request = client.get(url, headers, (response) => {
      if (response.statusCode < 200 || response.statusCode > 299) {
        reject(new Error('Failed with status code: ' + response.statusCode));
      }
      const body = [];
      response.on('data', (chunk) => body.push(chunk));
      response.on('end', () => resolve(body.join('')));
    });
    request.on('error', (err) => reject(err))
  })
};

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    PlayStreamIntentHandler,
    PlaybackStartedIntentHandler,
    CancelAndStopIntentHandler,
    PlaybackStoppedIntentHandler,
    HelpIntentHandler,
    ExceptionEncounteredRequestHandler,
    SessionEndedRequestHandler
  )
 .addErrorHandlers(ErrorHandler)
  .lambda();
 
